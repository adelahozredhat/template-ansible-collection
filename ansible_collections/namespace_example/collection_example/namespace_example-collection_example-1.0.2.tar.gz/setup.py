
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

from setuptools import setup, find_packages

setup(name="collection_example", packages=find_packages())
