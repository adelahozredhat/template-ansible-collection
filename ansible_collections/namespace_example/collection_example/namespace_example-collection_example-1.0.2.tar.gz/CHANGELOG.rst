==================================================
ansible_collection.namespace_example Release Notes
==================================================

.. contents:: Topics


v1.0.0
======

Release Summary
---------------

Initial example

Major Changes
-------------

- Add examples.

Minor Changes
-------------

- Add echo examples.

Breaking Changes / Porting Guide
--------------------------------

- Is an example.

Deprecated Features
-------------------

- Is new not deprecated modules.

Removed Features (previously deprecated)
----------------------------------------

- Is new not removed modules.

Security Fixes
--------------

- Is an example.

Bugfixes
--------

- Is an example.

New Modules
-----------

Namespace Example
~~~~~~~~~~~~~~~~~

collection_example
^^^^^^^^^^^^^^^^^^

- namespace_example.collection_example.get_servers - List servers

New Playbooks
-------------

- playbook - List servers and echo

New Roles
---------

- get_server_example_role - List servers
